import os

path = os.getenv("QCI_PLUGIN_RUNTIME", "./")

with open(os.path.join(path, 'status'), 'r') as fp:
    with open(os.path.join(path, 'status.json'), 'w') as fp2:
        fp2.write(fp.read())

